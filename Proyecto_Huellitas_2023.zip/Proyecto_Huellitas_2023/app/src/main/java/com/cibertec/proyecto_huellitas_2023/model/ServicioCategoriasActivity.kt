package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class ServicioCategoriasActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_serviciocategorias)



    }
}