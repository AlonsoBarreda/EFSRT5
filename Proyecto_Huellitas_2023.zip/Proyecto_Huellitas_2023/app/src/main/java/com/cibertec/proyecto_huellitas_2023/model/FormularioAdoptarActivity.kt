package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class FormularioAdoptarActivity : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formularioadoptar)


        //inyectas vistas

        val edtnombreadoptante: EditText= findViewById(R.id.edtnombreadoptante)
        val edtdni: EditText= findViewById(R.id.editdni)
        val edtemail: EditText= findViewById(R.id.editemail)
        val edtcel: EditText= findViewById(R.id.editcantidad)
        val edtdirec: EditText= findViewById(R.id.editdirecccion)
        val edttipo: EditText= findViewById(R.id.spmarcacomida)

        val btntramite : Button=findViewById(R.id.btntramiteAdop)

        //PARA EL TRAMITE ADOPCION

        btntramite.setOnClickListener{
            //RECUPERAR INFORMACION

            val nombreadoptante = edtnombreadoptante.text.toString()
            val dni = edtdni.text.toString()
            val mail = edtemail.text.toString()
            val cel = edtcel.text.toString()
            val dir = edtdirec.text.toString()
            val tipomascota = edttipo.text.toString()


            //VALIDAR QUE NO ESTÉN VACIOS LOS CAMPOS
            //VALIDACION nombres
            if(nombreadoptante.isEmpty()){
                Toast.makeText(this,"Debe ingresar sus nombres y apellidos", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            //VALIDACION dni
            if(dni.isEmpty()){
                Toast.makeText(this,"Debe ingresar su dni", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            //VALIDACION mail
            if(mail.isEmpty()){
                Toast.makeText(this,"Debe ingresar su email", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            //VALIDACION cel
            if(cel.isEmpty()){
                Toast.makeText(this,"Debe ingresar su celular", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            //VALIDACION cel
            if(dir.isEmpty()){
                Toast.makeText(this,"Debe ingresar su direccion", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            //GUARDAR INFORMACION TEMPORAL
            val bundle = Bundle().apply {
                putString("KEY_NOMBRE", nombreadoptante)
                putString("KEY_DNI", dni)
                putString("KEY_MAIL", mail)
                putString("KEY_CEL",cel)
                putString("KEY_DIR",dir)
                putString("KEY_TIPOMASC",tipomascota)
            }

            //navegar entre pantallas

            //cambiar a la nueva pantalla
            val intent = Intent(this,AdopcionFinalActivity::class.java).apply {
                putExtras(bundle)
            }
            startActivity(intent)
        }
//Asignando Valores desplegables a los rv
        val splTiposMascota: AutoCompleteTextView = findViewById(R.id.spmarcacomida)
        val tiposList: List<String> = listOf("LAZY-PERRO (3MESES)","LOGAN-GATO (8MESES)","PARRYT-LORO (2AÑOS)",
            "LUCKY-HAMNSTER(1AÑO)","LIZARD-LAGARTO (5AÑOS)","LUFFY-NUTRIA (10MESES)","PEPPER-GATO (10MESES)","GARY-GATO (7AÑOS)","THOR-PERRO (4AÑOS)",
        "OAK-LORO (5AÑOS)")
        //ME PERMITE ACCEDER A LOS ITEMS DEL MENU
        splTiposMascota.setAdapter(ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposList))

        }//fin listener





    }