package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class ProformaFinalActivity : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proformafinal)

//  INYECTAR
        val tvtexto: TextView = findViewById(R.id.txtResultados)
        val tvtextodos: TextView = findViewById(R.id.txtResultadofinal)


        //RECUPERAR EL BUNDLE
        val bundle : Bundle? = intent.extras
        bundle?.let { bundleLibreDeNulos ->
            val nombremascota = bundleLibreDeNulos.getString("KEY_NOMBRE") ?: "Desconocido"
            val tipomascota = bundleLibreDeNulos.getString("KEY_TIPOMASCOTA") ?: "Desconocido"
            val tiposervicio = bundleLibreDeNulos.getString("KEY_TIPOSERVICIO") ?: "Desconocido"
            val date = bundleLibreDeNulos.getString("KEY_DATE") ?: "Desconocido"
            val peso = bundleLibreDeNulos.getString("KEY_PESO") ?: "Desconocido"

        //PINTAR


            tvtexto.text ="La cita es para la mascota: $nombremascota " +
                    "- $tipomascota se solicita el servicio de $tiposervicio para la fecha: $date " +
                    "el peso de $nombremascota esta entre los $peso kg"

            tvtextodos.text="El precio final es de s/35.90 para concretar una cita deberá comunicarse a los siguientes números: " +
                    " 998758788 o a 995874445 "


        }
}
}