package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class CarritoComidaFinal : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carritocomidafinal)

    //INYECTAR
        val tvtexto: TextView = findViewById(R.id.txtResultados)


        //RECUPERAR EL BUNDLE
        val bundle : Bundle? = intent.extras
        bundle?.let { bundleLibreDeNulos ->


            val marca = bundleLibreDeNulos.getString("KEY_ALIMENTO") ?: "Desconocido"
            val canti = bundleLibreDeNulos.getString("KEY_CANTIDAD") ?: "Desconocido"
            val tipopago = bundleLibreDeNulos.getString("KEY_TIPOPAGO") ?: "Desconocido"

            //PINTAR


            tvtexto.text= "SE REALIZÓ LA COMPRA EXITOSAMENTE" +
                    " EL PROODUCTO COMPRADO ES: $marca  y la cantidad es  $canti KG/UN, el pago se realizó con $tipopago "

    }


    }
}