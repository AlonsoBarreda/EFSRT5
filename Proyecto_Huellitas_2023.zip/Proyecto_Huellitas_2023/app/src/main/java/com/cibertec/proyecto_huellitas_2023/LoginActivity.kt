package com.cibertec.proyecto_huellitas_2023

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import androidx.appcompat.widget.AppCompatButton
import com.cibertec.proyecto_huellitas_2023.model.FormularioRegistroActivity


class LoginActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        val btnLog = findViewById<AppCompatButton>(R.id.btnLog)
        btnLog.setOnClickListener{
            startActivity(Intent(this,
                IndexActivity::class.java))
        }

        val btnregister = findViewById<AppCompatButton>(R.id.btnregister)
        btnregister.setOnClickListener{
            startActivity(Intent(this,
                FormularioRegistroActivity::class.java))


    }
}
}