package com.cibertec.proyecto_huellitas_2023.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName= "tableperritos")
data class AdopcionPerritos(

    //AUTOGENERADO
    @PrimaryKey(autoGenerate = true)
    val id:Int,

    @ColumnInfo(name = "nombre")
    val nombreperro:String,
    val especie:String,
    val edadperro:String
) :java.io.Serializable