package com.cibertec.proyecto_huellitas_2023.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.cibertec.proyecto_huellitas_2023.secondmodel.Proforma

@Dao
interface ProformaDao {

    //REGISTRAR
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(proforma: Proforma)


    //OBTENER
    @Query("SELECT * FROM tableproforma order by id desc")
    fun getAllProformas(): LiveData<List<Proforma>>


}