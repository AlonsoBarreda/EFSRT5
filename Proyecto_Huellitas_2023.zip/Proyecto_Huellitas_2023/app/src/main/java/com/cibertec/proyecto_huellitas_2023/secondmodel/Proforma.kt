package com.cibertec.proyecto_huellitas_2023.secondmodel

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tableproforma")

data class Proforma (


    @PrimaryKey(autoGenerate = true)
    val id:Int,

    @ColumnInfo(name = "nombre")
    val nombremascota:String,
    val tipomascota:String,
    val tiposervicio:String,
    val fecha:String,
    val pesomascota:String

        ): java.io.Serializable

