package com.cibertec.proyecto_huellitas_2023.model

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

import com.cibertec.proyecto_huellitas_2023.R
import com.cibertec.proyecto_huellitas_2023.database.AppDatabase
import com.cibertec.proyecto_huellitas_2023.databinding.ActivityAdopcionperritosBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext



class   AdopcionPerritosActivity : AppCompatActivity() {

    private lateinit var binding :ActivityAdopcionperritosBinding


    private val adopcionPerritosAdapter = AdopcionPerritosAdapter(onItemDetail = { perrito ->

        val bundle = Bundle().apply {
            putSerializable("KEY_ADOPTPERRITOS",perrito)
        }
        val intent = Intent(this,MenuAdopcionActivity::class.java).apply {
            putExtras(bundle)
        }
        startActivity(intent)

    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAdopcionperritosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvListaPerritos.adapter = adopcionPerritosAdapter
        AppDatabase.getInstance(this).adopcionPerritosDao().getAllMatriculas()

        getAllMatriculas()
        setContentView(R.layout.activity_adopcionperritos)


    }


    private fun getAllMatriculas(){
        GlobalScope.launch(Dispatchers.Main) {
        binding.progressBar.visibility = View.VISIBLE
        AppDatabase.getInstance(this@AdopcionPerritosActivity).adopcionPerritosDao().getAllMatriculas().observe(this@AdopcionPerritosActivity){ perritos ->

        }
        binding.progressBar.visibility = View.GONE
        }
    }
}