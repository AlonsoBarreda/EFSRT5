package com.cibertec.proyecto_huellitas_2023.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

import com.cibertec.proyecto_huellitas_2023.model.AdopcionPerritos

@Dao
interface AdopcionPerritosDao {

    //CRUDS

    //REGISTRAR
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(perritos: AdopcionPerritos)


    //OBTENER
    @Query("SELECT * FROM tableperritos order by id desc")
    fun getAllMatriculas(): LiveData<List<AdopcionPerritos>>

}