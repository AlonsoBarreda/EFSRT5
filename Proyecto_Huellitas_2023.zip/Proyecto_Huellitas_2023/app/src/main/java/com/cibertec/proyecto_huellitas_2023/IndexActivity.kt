package com.cibertec.proyecto_huellitas_2023

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.cibertec.proyecto_huellitas_2023.R
import com.cibertec.proyecto_huellitas_2023.IndexActivity
import com.cibertec.proyecto_huellitas_2023.R.id.btnAdoptar
import com.cibertec.proyecto_huellitas_2023.model.MenuAdopcionActivity
import com.cibertec.proyecto_huellitas_2023.model.MenuTiendaActivity

class IndexActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_index)


        val btnAdoptar = findViewById<ImageButton>(R.id.btnAdoptar)
        btnAdoptar.setOnClickListener{
            startActivity(Intent(this,
                MenuAdopcionActivity::class.java))
        }

        val btnProductos = findViewById<ImageButton>(R.id.btnProductos)
        btnProductos.setOnClickListener{
            startActivity(Intent(this,
                MenuTiendaActivity::class.java))
        }
    }
}