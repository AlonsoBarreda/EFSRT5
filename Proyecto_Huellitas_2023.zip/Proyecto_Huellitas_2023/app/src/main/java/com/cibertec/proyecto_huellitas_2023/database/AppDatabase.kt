package com.cibertec.proyecto_huellitas_2023.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.cibertec.proyecto_huellitas_2023.model.AdopcionPerritos

@Database(entities = [AdopcionPerritos::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    abstract fun adopcionPerritosDao(): AdopcionPerritosDao

    companion object{

        var appDatabase : AppDatabase? = null

        fun getInstance(context:Context) : AppDatabase{

            if(appDatabase == null){
                //Crear la bd
                appDatabase = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "db_adopcion"
                ).build()
            }
            return appDatabase!!

        }
    }
}