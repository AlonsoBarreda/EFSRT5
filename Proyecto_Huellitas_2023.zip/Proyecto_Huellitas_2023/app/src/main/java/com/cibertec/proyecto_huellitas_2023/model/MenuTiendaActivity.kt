package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.cibertec.proyecto_huellitas_2023.R

class MenuTiendaActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menutienda)

        val btnProSer = findViewById<ImageButton>(R.id.btnProSer)
        btnProSer.setOnClickListener{
            startActivity(Intent(this,
                TiendaCategoriasActivity::class.java))
        }

        val btnVariados = findViewById<ImageButton>(R.id.btnVariados)
        btnVariados.setOnClickListener{
            startActivity(Intent(this,
                ServicioCategoriasActivity::class.java))
        }

//btnFrmCotz

        val btnFrmCotz = findViewById<AppCompatButton>(R.id.btnFrmCotz)
        btnFrmCotz.setOnClickListener{
            startActivity(Intent(this,
                FormularioServiciosActivity::class.java))
        }

    }
}