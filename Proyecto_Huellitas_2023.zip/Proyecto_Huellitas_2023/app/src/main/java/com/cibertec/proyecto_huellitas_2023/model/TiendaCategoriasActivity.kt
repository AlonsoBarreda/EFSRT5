package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class TiendaCategoriasActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tiendacategorias)

        val btnComida = findViewById<ImageButton>(R.id.btnComida)
        btnComida.setOnClickListener{
            startActivity(Intent(this,
                CarritoComidaActivity::class.java))
        }

    }
}