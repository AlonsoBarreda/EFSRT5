package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class MenuAdopcionActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menuadopcion)


        val btnFrmAdop = findViewById<Button>(R.id.btnFrmAdop)
        btnFrmAdop.setOnClickListener{
            startActivity(
                Intent(this,
                    FormularioAdoptarActivity::class.java)
            )
        }

        //btnPerros
        val btnPerros = findViewById<ImageButton>(R.id.btnPerros)
        btnPerros.setOnClickListener{
            startActivity(Intent(this,
                AdopcionPerritosAdapter::class.java))
        }

    }
}