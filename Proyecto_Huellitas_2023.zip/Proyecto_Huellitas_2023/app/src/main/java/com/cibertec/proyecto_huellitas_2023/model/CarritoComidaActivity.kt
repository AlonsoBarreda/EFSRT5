package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class CarritoComidaActivity : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carritocomida)


        //inyectas vistas

        val slcmarca: EditText = findViewById(R.id.spmarcacomida)
        val cantidad: EditText = findViewById(R.id.editcantidad)
        val rbdebito: RadioButton = findViewById(R.id.rbTarjeta)
        val rbcredito: RadioButton = findViewById(R.id.rbcredito)
        val nrotarjeta: EditText = findViewById(R.id.edtNumTarj)
        val mesvencimiento: EditText = findViewById(R.id.edtVencimiento)
        val anioven: EditText = findViewById(R.id.edtAñoVen)
        val cvv: EditText = findViewById(R.id.edtCVV)

        val btnPagar: Button = findViewById(R.id.btnPagar)

        btnPagar.setOnClickListener{

            val marca = slcmarca.text.toString()
            val canti = cantidad.text.toString()
            val tipopago =if(rbdebito.isChecked)"paga con tarjeta de debito" else "paga con tarjeta de credito"
            val mesvenci = mesvencimiento.text.toString()
            val aniovencimiento = anioven.text.toString()
            val cvvtarjeta = cvv.text.toString()


            //GUARDAR INFORMACION TEMPORAL
            val bundle = Bundle().apply {
                putString("KEY_ALIMENTO", marca)
                putString("KEY_CANTIDAD",canti)
                putString("KEY_TIPOPAGO",tipopago)
                putString("KEY_MESVENCIMIENTO",mesvenci)
                putString("KEY_ANIOVENCIMIENTO",aniovencimiento)
                putString("KEY_CVV",cvvtarjeta)

        }//finonclick

            //navegar entre pantallas
            val intent = Intent(this,CarritoComidaFinal::class.java).apply {
                putExtras(bundle)
            }
            startActivity(intent)
        }

        //Asignando Valores desplegables a los rv
        val splMarcaComida: AutoCompleteTextView = findViewById(R.id.spmarcacomida)
        val comidaList: List<String> = listOf("RICOCAN CORDERO - S/15.00 KG","CAMBO - S/9.00 KG","FOODFISH S/5.50 KG",
            "ALPISTE FENIX S/9.50 KG","LAGARTINA S/6.50 KG","RICOCAT S/8.50 KG","DOGSHOW S/9.00 KG","ALPISTE DELUXE S/15.00KG",
            "LATA SALMON S/5.50 UNIDAD",
            "CARNE ENLATADA S/8.00 UNIDAD")
        //ME PERMITE ACCEDER A LOS ITEMS DEL MENU
        splMarcaComida.setAdapter(ArrayAdapter(this, android.R.layout.simple_spinner_item, comidaList))
    }//SET on Click Listener


}