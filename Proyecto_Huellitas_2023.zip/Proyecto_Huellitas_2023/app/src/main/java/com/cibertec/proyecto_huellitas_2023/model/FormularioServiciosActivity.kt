package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R
import com.cibertec.proyecto_huellitas_2023.databinding.ActivityFormularioserviciosBinding
import com.cibertec.proyecto_huellitas_2023.secondmodel.Proforma
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class FormularioServiciosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFormularioserviciosBinding

        @SuppressLint("WrongViewCast")
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_formularioservicios)

            //inyectar vistas

            val edtnombremascota: EditText = findViewById(R.id.edtnombremascota)

            val slctipomascota: EditText = findViewById(R.id.spmarcacomida)
            val slctiposervicio: EditText = findViewById(R.id.sptiposervicio)
            val edtdate: EditText = findViewById(R.id.edtdate)
            val rbpesouno: RadioButton = findViewById(R.id.rb05)
            val rbpesodos: RadioButton = findViewById(R.id.rb510)
            val rbpesotres: RadioButton = findViewById(R.id.rb10amas)

            val btnProfor: Button=findViewById(R.id.btnPagar)
//

            //PARA LA PROFORMA AL LISTAR

            btnProfor.setOnClickListener{

             //RECUPERAR INFORMACION
            val nombremascota = edtnombremascota.text.toString()
            val tipomascota = slctipomascota.text.toString()
                val tiposervicio = slctiposervicio.text.toString()
                val date= edtdate.text.toString()
                val peso =if(rbpesouno.isChecked)"0 a 5" else if (rbpesodos.isChecked)"5 a 10" else "10 a +"

                val proforma = Proforma(0,nombremascota,tipomascota,tiposervicio,date,peso)

                GlobalScope.launch(Dispatchers.Main) {

            }

                //VALIDAR QUE NO ESTÉN VACIOS LOS CAMPOS
                //VALIDACION DNI
                if(nombremascota.isEmpty()){
                Toast.makeText(this,"Debe el nombre de su mascota", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
                //VALIDACION NOMBRES
                if(date.isEmpty()){
                    Toast.makeText(this,"Debe ingresar una fecha", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }


                //GUARDAR INFORMACION TEMPORAL
                val bundle = Bundle().apply {
                    putString("KEY_NOMBRE", nombremascota)
                    putString("KEY_TIPOMASCOTA",tipomascota)
                    putString("KEY_TIPOSERVICIO",tiposervicio)
                    putString("KEY_DATE",date)
                    putString("KEY_PESO",peso)

                }

                //navegar entre pantallas
                val intent = Intent(this,ProformaFinalActivity::class.java).apply {
                    putExtras(bundle)
                }
                startActivity(intent)
            }

            //Asignando Valores desplegables a los rv
            val splTiposMascota: AutoCompleteTextView = findViewById(R.id.spmarcacomida)
            val tiposList: List<String> = listOf("PERRO","GATO","LORO","HAMNSTER","LAGARTOS")
            //ME PERMITE ACCEDER A LOS ITEMS DEL MENU
            splTiposMascota.setAdapter(ArrayAdapter(this, android.R.layout.simple_spinner_item, tiposList))

            //Asignando Valores desplegables a los rv
            val splTiposServicio: AutoCompleteTextView = findViewById(R.id.sptiposervicio)
            val serviciosList: List<String> = listOf("CORTE","CEPILLADO DENTAL","BAÑO","BAÑO MEDICADO","BAÑO Y CORTE","PIPETA 1 MES","PIPETA 3 MESES","INY. DISTEMPER","INY. ANTIRABIA",
            "INY. DESPARACITADORA","INY. CALCIO","INY. TRIPLE")
            //ME PERMITE ACCEDER A LOS ITEMS DEL MENU
            splTiposServicio.setAdapter(ArrayAdapter(this, android.R.layout.simple_spinner_item, serviciosList))
        }//SET on Click Listener


}

