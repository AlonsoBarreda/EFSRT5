package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.cibertec.proyecto_huellitas_2023.LoginActivity
import com.cibertec.proyecto_huellitas_2023.R

class FormularioRegistroActivity : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formularioregistro)

        val btnNewUser = findViewById<AppCompatButton>(R.id.btntramiteAdop)
        btnNewUser.setOnClickListener{
            startActivity(
                Intent(this,
                LoginActivity::class.java)
            )

            //MANDAR MENSAJE DE REGISTRO
        }

        val btnVolver = findViewById<AppCompatButton>(R.id.btnVolver)
        btnVolver.setOnClickListener{
            startActivity(
                Intent(this,
                    LoginActivity::class.java)
            )
        }


    }
}