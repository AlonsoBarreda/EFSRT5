package com.cibertec.proyecto_huellitas_2023.model

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cibertec.proyecto_huellitas_2023.R
import com.cibertec.proyecto_huellitas_2023.databinding.ItemPerritosBinding

class AdopcionPerritosAdapter(val perritos: List<AdopcionPerritos> = emptyList(), val onItemDetail:(AdopcionPerritos)->Unit):RecyclerView.Adapter<AdopcionPerritosAdapter.ViewHolder>() {

    //definir el view holder

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
    private val binding: ItemPerritosBinding =ItemPerritosBinding.bind(itemView)

        fun bind(perritos: AdopcionPerritos) {

            binding.tvName.text = perritos.nombreperro
            binding.tvtipoMasc.text = perritos.especie
        }
}
    override fun getItemCount(): Int {
        return perritos.size
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdopcionPerritosAdapter.ViewHolder {
       val itemView: View = LayoutInflater.from(parent.context).inflate(R.layout.item_perritos,parent,false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
       val perrito =perritos[position]
        holder.bind(perrito)
    }

}
