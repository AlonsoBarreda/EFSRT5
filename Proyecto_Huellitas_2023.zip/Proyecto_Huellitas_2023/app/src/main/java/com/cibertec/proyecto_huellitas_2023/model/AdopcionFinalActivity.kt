package com.cibertec.proyecto_huellitas_2023.model

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.cibertec.proyecto_huellitas_2023.R

class AdopcionFinalActivity : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adopcionfinal)

//  INYECTAR
        val tvtexto: TextView = findViewById(R.id.txtResultados)
        val tvtextodos: TextView = findViewById(R.id.txtResultadofinal)


        //RECUPERAR EL BUNDLE
        val bundle : Bundle? = intent.extras
        bundle?.let { bundleLibreDeNulos ->
            val nombreadoptante = bundleLibreDeNulos.getString("KEY_NOMBRE") ?: "Desconocido"
            val dni = bundleLibreDeNulos.getString("KEY_DNI") ?: "Desconocido"
            val mail = bundleLibreDeNulos.getString("KEY_MAIL") ?: "Desconocido"
            val cel = bundleLibreDeNulos.getString("KEY_CEL") ?: "Desconocido"
            val dir = bundleLibreDeNulos.getString("KEY_DIR") ?: "Desconocido"
            val tipomascota = bundleLibreDeNulos.getString("KEY_TIPOMASC") ?: "Desconocido"



        //PINTAR


            tvtexto.text ="HUELLITAS se complace en saludar a : $nombreadoptante registrado con el DNI"+
                    "- $dni quien está interesado en  $tipomascota. Nos contactaremos con usted al nro: $cel " +
                    "se le enviará una carta a la siguiente dirección: $dir en el cual se adjunta la documentación adicional al proceso" +
                    " esta información también se le enviará al correo: $mail"


            tvtextodos.text="En el transcurso de las horas uno de los siguientes números se pondrán en contacto con usted " +
                    " (998758788 o a 995874445) "


        }
}
}